<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Surat Jalan #{{ $sale->invoice_number }}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            line-height: 1.4;
            color: #333;
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
        }

        .company-name {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .company-details {
            font-size: 12px;
            color: #555;
        }

        .document-title {
            font-size: 16px;
            font-weight: bold;
            text-align: center;
            margin: 20px 0;
            text-decoration: underline;
        }

        .document-number {
            font-size: 14px;
            text-align: center;
            margin-bottom: 20px;
        }

        .section {
            margin-bottom: 20px;
        }

        .section-title {
            font-weight: bold;
            margin-bottom: 5px;
            border-bottom: 1px solid #ddd;
            padding-bottom: 3px;
        }

        .details-table {
            width: 100%;
            margin-bottom: 15px;
        }

        .details-table td {
            padding: 3px 0;
        }

        .label {
            font-weight: bold;
            width: 150px;
        }

        table.items {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table.items th {
            background-color: #f2f2f2;
            text-align: left;
            padding: 8px;
            border: 1px solid #000;
        }

        table.items td {
            padding: 8px;
            border: 1px solid #000;
        }

        .signatures {
            margin-top: 40px;
            width: 100%;
        }

        .signature-box {
            float: left;
            width: 33%;
            text-align: center;
        }

        .signature-line {
            border-top: 1px solid #000;
            margin-top: 50px;
            display: inline-block;
            width: 80%;
        }

        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 11px;
            color: #777;
            border-top: 1px solid #ddd;
            padding-top: 10px;
        }
    </style>
</head>

<body>
    <div class="header">
        <div class="company-name">TOKO PUPUK</div>
        <div class="company-details">
            Jl. Contoh No. 123, Kota<br>
            Telp: 0123456789 | Email: info@tokopupuk.com
        </div>
    </div>

    <div class="document-title">SURAT JALAN</div>
    <div class="document-number">No: SJ-{{ $sale->invoice_number }}</div>

    <div class="section">
        <div class="section-title">Informasi Pengiriman</div>
        <table class="details-table">
            <tr>
                <td class="label">Tanggal Pengiriman:</td>
                <td>{{ \Carbon\Carbon::parse($sale->date)->format('d/m/Y') }}</td>
            </tr>
            <tr>
                <td class="label">No. Referensi:</td>
                <td>{{ $sale->invoice_number }}</td>
            </tr>
            @if ($sale->vehicle_type || $sale->vehicle_number)
                <tr>
                    <td class="label">Kendaraan:</td>
                    <td>{{ $sale->vehicle_type }} {{ $sale->vehicle_number ? '(' . $sale->vehicle_number . ')' : '' }}
                    </td>
                </tr>
            @endif
        </table>
    </div>

    @if ($sale->customer)
        <div class="section">
            <div class="section-title">Tujuan Pengiriman</div>
            <table class="details-table">
                <tr>
                    <td class="label">Nama Penerima:</td>
                    <td>{{ $sale->customer->nama }}</td>
                </tr>
                <tr>
                    <td class="label">Alamat Pengiriman:</td>
                    <td>
                        {{ $sale->customer->alamat ?? '-' }},
                        {{ $sale->customer->desa_nama }},
                        {{ $sale->customer->kecamatan_nama }},
                        {{ $sale->customer->kabupaten_nama }},
                        {{ $sale->customer->provinsi_nama }}
                    </td>
                </tr>
            </table>
        </div>
    @endif

    <div class="section">
        <div class="section-title">Detail Barang</div>
        <table class="items">
            <thead>
                <tr>
                    <th width="5%">No</th>
                    <th width="15%">Kode</th>
                    <th width="50%">Nama Barang</th>
                    <th width="10%">Jumlah</th>
                    <th width="20%">Keterangan</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($saleDetails as $index => $detail)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>{{ $detail->product->code }}</td>
                        <td>{{ $detail->product->name }}</td>
                        <td>{{ $detail->quantity }}</td>
                        <td></td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    @if ($sale->notes)
        <div class="section">
            <div class="section-title">Catatan</div>
            <p>{{ $sale->notes }}</p>
        </div>
    @endif

    <table class="signatures">
        <tr>
            <td width="33%" style="text-align: center;">
                Penerima
                <div class="signature-line"></div>
                <div style="margin-top: 5px;">(............................................)</div>
            </td>
            <td width="33%" style="text-align: center;">
                Pengirim
                <div class="signature-line"></div>
                <div style="margin-top: 5px;">(............................................)</div>
            </td>
            <td width="33%" style="text-align: center;">
                Hormat Kami
                <div class="signature-line"></div>
                <div style="margin-top: 5px;">(............................................)</div>
            </td>
        </tr>
    </table>

    <div class="footer">
        <p>Barang telah diterima dalam kondisi baik dan sesuai dengan pesanan.</p>
    </div>
</body>

</html>
