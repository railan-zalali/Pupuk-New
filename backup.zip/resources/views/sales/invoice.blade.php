<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Invoice #{{ $sale->invoice_number }}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            line-height: 1.4;
            color: #333;
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }

        .company-name {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .company-details {
            font-size: 12px;
            color: #555;
        }

        .invoice-title {
            font-size: 16px;
            font-weight: bold;
            text-align: center;
            margin: 20px 0;
            text-decoration: underline;
        }

        .invoice-details,
        .customer-details {
            width: 100%;
            margin-bottom: 20px;
        }

        .invoice-details td,
        .customer-details td {
            padding: 3px 0;
        }

        .label {
            font-weight: bold;
            width: 120px;
        }

        table.items {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table.items th {
            background-color: #f2f2f2;
            text-align: left;
            padding: 8px;
            border: 1px solid #ddd;
        }

        table.items td {
            padding: 8px;
            border: 1px solid #ddd;
        }

        .totals {
            width: 100%;
            margin-top: 20px;
        }

        .totals td {
            padding: 3px 0;
        }

        .total-label {
            text-align: right;
            font-weight: bold;
            width: 80%;
        }

        .total-value {
            text-align: right;
            width: 20%;
        }

        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 11px;
            color: #777;
        }

        .signatures {
            margin-top: 40px;
            width: 100%;
        }

        .signature-box {
            float: left;
            width: 30%;
            text-align: center;
        }

        .signature-line {
            border-top: 1px solid #000;
            margin-top: 50px;
            display: inline-block;
            width: 80%;
        }
    </style>
</head>

<body>
    <div class="header">
        <div class="company-name">TOKO PUPUK</div>
        <div class="company-details">
            Jl. Contoh No. 123, Kota<br>
            Telp: 0123456789 | Email: info@tokopupuk.com
        </div>
    </div>

    <div class="invoice-title">INVOICE</div>

    <table class="invoice-details">
        <tr>
            <td class="label">No. Invoice:</td>
            <td>{{ $sale->invoice_number }}</td>
            <td class="label">Tanggal:</td>
            <td>{{ \Carbon\Carbon::parse($sale->date)->format('d/m/Y') }}</td>
        </tr>
        <tr>
            <td class="label">Metode Pembayaran:</td>
            <td>
                @if ($sale->payment_method == 'cash')
                    Tunai
                @elseif($sale->payment_method == 'credit')
                    Kredit
                @elseif($sale->payment_method == 'transfer')
                    Transfer Bank
                @endif
            </td>
            <td class="label">Kasir:</td>
            <td>{{ $sale->user->name }}</td>
        </tr>
    </table>

    @if ($sale->customer)
        <table class="customer-details">
            <tr>
                <td class="label">Nama Pelanggan:</td>
                <td>{{ $sale->customer->nama }}</td>
            </tr>
            <tr>
                <td class="label">Alamat:</td>
                <td>
                    {{ $sale->customer->alamat ?? '-' }},
                    {{ $sale->customer->desa_nama }},
                    {{ $sale->customer->kecamatan_nama }}
                </td>
            </tr>
        </table>
    @endif

    <!-- Update the invoice table to show units -->
<table class="items">
    <thead>
        <tr>
            <th>No</th>
            <th>Produk</th>
            <th>Harga</th>
            <th>Satuan</th>
            <th>Jumlah</th>
            <th>Subtotal</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($sale->saleDetails as $index => $detail)
            <tr>
                <td>{{ $index + 1 }}</td>
                <td>
                    <strong>{{ $detail->product->name }}</strong><br>
                    <small>{{ $detail->product->code }}</small>
                </td>
                <td>Rp {{ number_format($detail->price, 0, ',', '.') }}</td>
                <td>{{ $detail->productUnit->unit->abbreviation }}</td>
                <td>{{ $detail->quantity }}</td>
                <td>Rp {{ number_format($detail->subtotal, 0, ',', '.') }}</td>
            </tr>
        @endforeach
    </tbody>
</table>

    <table class="totals">
        <tr>
            <td class="total-label">Total:</td>
            <td class="total-value">Rp {{ number_format($sale->total_amount, 0, ',', '.') }}</td>
        </tr>
        @if ($sale->discount > 0)
            <tr>
                <td class="total-label">Diskon:</td>
                <td class="total-value">Rp {{ number_format($sale->discount, 0, ',', '.') }}</td>
            </tr>
            <tr>
                <td class="total-label">Total Setelah Diskon:</td>
                <td class="total-value">Rp {{ number_format($sale->total_amount - $sale->discount, 0, ',', '.') }}</td>
            </tr>
        @endif
        <tr>
            <td class="total-label">Dibayar:</td>
            <td class="total-value">Rp {{ number_format($sale->paid_amount, 0, ',', '.') }}</td>
        </tr>
        <tr>
            <td class="total-label">Kembali:</td>
            <td class="total-value">Rp {{ number_format($sale->change_amount, 0, ',', '.') }}</td>
        </tr>
        @if ($sale->payment_method === 'credit' && $sale->remaining_amount > 0)
            <tr>
                <td class="total-label">Sisa Hutang:</td>
                <td class="total-value">Rp {{ number_format($sale->remaining_amount, 0, ',', '.') }}</td>
            </tr>
            @if ($sale->due_date)
                <tr>
                    <td class="total-label">Jatuh Tempo:</td>
                    <td class="total-value">{{ \Carbon\Carbon::parse($sale->due_date)->format('d/m/Y') }}</td>
                </tr>
            @endif
        @endif
    </table>

    @if ($sale->notes)
        <div style="margin-top: 20px; border: 1px solid #ddd; padding: 10px;">
            <strong>Catatan:</strong><br>
            {{ $sale->notes }}
        </div>
    @endif

    <table class="signatures">
        <tr>
            <td width="33%" style="text-align: center;">
                Penerima
                <div class="signature-line"></div>
            </td>
            <td width="33%" style="text-align: center;">
                Pengirim
                <div class="signature-line"></div>
            </td>
            <td width="33%" style="text-align: center;">
                Hormat Kami
                <div class="signature-line"></div>
            </td>
        </tr>
    </table>

    <div class="footer">
        Terima kasih atas kepercayaan Anda berbelanja di Toko Pupuk.<br>
        Barang yang sudah dibeli tidak dapat dikembalikan.
    </div>
</body>

</html>
