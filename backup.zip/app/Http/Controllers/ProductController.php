<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category;
use App\Models\ProductUnit;
use App\Models\StockMovement;
use App\Models\Supplier;
use App\Models\UnitOfMeasure;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::with('category')
            ->orderByRaw('CASE WHEN stock < min_stock THEN 0 ELSE 1 END')
            ->orderBy('stock')
            ->paginate(10);
        return view('products.index', compact('products'));
    }

    public function create()
    {
        $categories = Category::orderBy('name')->get();
        $suppliers = Supplier::orderBy('name')->get();
        $units = UnitOfMeasure::orderBy('name')->get();

        // Generate a unique product code
        $today = date('Ymd');
        $baseCode = 'PRD-' . $today . '-';

        // Find the highest number for today's products
        $lastProduct = Product::withTrashed()->where('code', 'like', $baseCode . '%')
            ->orderBy('code', 'desc')
            ->first();

        $lastNumber = 0;
        if ($lastProduct) {
            $lastNumber = (int) substr($lastProduct->code, -4);
        }

        // Generate new code
        $newNumber = $lastNumber + 1;
        $productCode = $baseCode . str_pad($newNumber, 4, '0', STR_PAD_LEFT);

        // Make sure it's unique
        while (Product::withTrashed()->where('code', $productCode)->exists()) {
            $newNumber++;
            $productCode = $baseCode . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
        }

        return view('products.create', compact('categories', 'productCode', 'suppliers', 'units'));
    }

    public function store(Request $request)
    {
        try {
            DB::beginTransaction();
            // Check if this is a batch submission
            if ($request->input('is_batch') == 1) {
                return $this->storeBatch($request);
            }

            // Re-check if the code is unique before validating
            $code = $request->input('code');
            if (Product::withTrashed()->where('code', $code)->exists()) {
                // Generate a new unique code
                $today = date('Ymd');
                $baseCode = 'PRD-' . $today . '-';
                $lastProduct = Product::where('code', 'like', $baseCode . '%')
                    ->orderBy('code', 'desc')
                    ->first();

                $lastNumber = $lastProduct ? (int) substr($lastProduct->code, -4) : 0;
                $newNumber = $lastNumber + 1;
                $newCode = $baseCode . str_pad($newNumber, 4, '0', STR_PAD_LEFT);

                // Make sure new code is unique
                while (Product::withTrashed()->where('code', $newCode)->exists()) {
                    $newNumber++;
                    $newCode = $baseCode . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
                }

                // Replace the code in the request
                $request->merge(['code' => $newCode]);
            }

            $validated = $request->validate([
                'category_id' => 'required|exists:categories,id',
                'supplier_id' => 'required|exists:suppliers,id',
                'name' => 'required|string|max:255',
                'code' => 'required|string|unique:products,code,NULL,id,deleted_at,NULL',
                'description' => 'nullable|string',
                'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
                'stock' => 'required|integer|min:0',
                'min_stock' => 'required|integer|min:0',
                'units' => 'required|array|min:1',
                'units.*.unit_id' => 'required|exists:unit_of_measures,id',
                'units.*.conversion_factor' => 'required|numeric|min:1',
                'units.*.purchase_price' => 'required|numeric|min:0',
                'units.*.selling_price' => 'required|numeric|min:0',
                'units.*.barcode' => 'nullable|string',
                'units.*.is_default' => 'nullable'
            ]);

            // Process image if uploaded
            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $imageName = time() . '_' . $image->getClientOriginalName();

                // Make sure the directory exists
                Storage::makeDirectory('public/products');

                // Store the image with a consistent path
                $image->storeAs('products', $imageName, 'public');
                $validated['image_path'] = 'products/' . $imageName;
            }

            // Get base unit values for product table
            $baseUnitIndex = null;
            foreach ($request->units as $index => $unit) {
                if (isset($unit['is_default']) && $unit['is_default']) {
                    $baseUnitIndex = $index;
                    break;
                }
            }

            if ($baseUnitIndex === null) {
                // If no default unit is marked, use the first one
                $baseUnitIndex = 0;
            }

            // Create product with base unit values
            $product = Product::create([
                'category_id' => $validated['category_id'],
                'supplier_id' => $validated['supplier_id'],
                'name' => $validated['name'],
                'code' => $validated['code'],
                'description' => $validated['description'] ?? null,
                'image_path' => $validated['image_path'] ?? null,
                'purchase_price' => $request->units[$baseUnitIndex]['purchase_price'],
                'selling_price' => $request->units[$baseUnitIndex]['selling_price'],
                'stock' => $validated['stock'],
                'min_stock' => $validated['min_stock']
            ]);

            // Create product units
            foreach ($request->units as $index => $unitData) {
                ProductUnit::create([
                    'product_id' => $product->id,
                    'unit_id' => $unitData['unit_id'],
                    'conversion_factor' => $unitData['conversion_factor'],
                    'purchase_price' => $unitData['purchase_price'],
                    'selling_price' => $unitData['selling_price'],
                    'barcode' => $unitData['barcode'] ?? null,
                    'is_default' => isset($unitData['is_default']) ? true : ($index == $baseUnitIndex)
                ]);
            }

            // Record initial stock movement
            $initialStock = $validated['stock'];
            if ($initialStock > 0) {
                StockMovement::create([
                    'product_id' => $product->id,
                    'type' => 'in',
                    'quantity' => $initialStock,
                    'before_stock' => 0,
                    'after_stock' => $initialStock,
                    'reference_type' => 'initial',
                    'reference_id' => $product->id,
                    'notes' => 'Initial stock'
                ]);
            }

            DB::commit();
            return redirect()->route('products.index')->with('success', 'Product created successfully');
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error creating product: ' . $e->getMessage());
            return back()->withInput()->with('error', 'Failed to create product: ' . $e->getMessage());
        }
    }

    public function storeBatch(Request $request)
    {
        try {
            DB::beginTransaction();

            $request->validate([
                'supplier_id' => 'required|exists:suppliers,id',
                'products' => 'required|array|min:1',
                'products.*.category_id' => 'required|exists:categories,id',
                'products.*.name' => 'required|string|max:255',
                'products.*.purchase_price' => 'required|numeric|min:0',
                'products.*.selling_price' => 'required|numeric|min:0',
                'products.*.stock' => 'required|integer|min:0',
                'products.*.min_stock' => 'required|integer|min:0',
                'products.*.unit_id' => 'required|exists:unit_of_measures,id',
                'products.*.description' => 'nullable|string',
            ]);

            // Log untuk debug
            Log::info('Request batch product masuk', [
                'supplier_id' => $request->supplier_id,
                'is_batch' => $request->is_batch,
                'products_count' => count($request->products),
                'request_data' => $request->all()
            ]);

            $today = date('Ymd');
            $baseCode = 'PRD-' . $today . '-';

            // Find the highest number for today's products
            $lastProduct = Product::withTrashed()->where('code', 'like', $baseCode . '%')
                ->orderBy('code', 'desc')
                ->first();

            $lastNumber = 0;
            if ($lastProduct) {
                $lastNumber = (int) substr($lastProduct->code, -4);
            }

            $createdProducts = [];
            $supplierId = $request->input('supplier_id');

            // Ambil supplier untuk log
            $supplier = Supplier::find($supplierId);
            Log::info('Processing batch dengan supplier', [
                'supplier_id' => $supplierId,
                'supplier_name' => $supplier ? $supplier->name : 'Unknown'
            ]);

            foreach ($request->products as $index => $productData) {
                // Generate new code for each product
                $newNumber = ++$lastNumber;
                $productCode = $baseCode . str_pad($newNumber, 4, '0', STR_PAD_LEFT);

                // Make sure it's unique
                while (Product::withTrashed()->where('code', $productCode)->exists()) {
                    $newNumber++;
                    $productCode = $baseCode . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
                }

                // Log produk yang sedang dibuat
                Log::info('Membuat produk batch #' . ($index + 1), [
                    'product_name' => $productData['name'],
                    'product_code' => $productCode,
                    'category_id' => $productData['category_id'],
                    'unit_id' => $productData['unit_id']
                ]);

                // Create the product
                $product = Product::create([
                    'category_id' => $productData['category_id'],
                    'supplier_id' => $supplierId,
                    'name' => $productData['name'],
                    'code' => $productCode,
                    'description' => $productData['description'] ?? null,
                    'purchase_price' => $productData['purchase_price'],
                    'selling_price' => $productData['selling_price'],
                    'stock' => $productData['stock'],
                    'min_stock' => $productData['min_stock']
                ]);

                Log::info('Produk batch berhasil dibuat', [
                    'product_id' => $product->id,
                    'product_name' => $product->name
                ]);

                // Create default product unit
                $productUnit = ProductUnit::create([
                    'product_id' => $product->id,
                    'unit_id' => $productData['unit_id'],
                    'conversion_factor' => 1, // Base unit
                    'purchase_price' => $productData['purchase_price'],
                    'selling_price' => $productData['selling_price'],
                    'is_default' => true
                ]);

                Log::info('Unit produk batch berhasil dibuat', [
                    'product_unit_id' => $productUnit->id,
                    'unit_id' => $productUnit->unit_id
                ]);

                // Record initial stock movement if needed
                if ($productData['stock'] > 0) {
                    $stockMovement = StockMovement::create([
                        'product_id' => $product->id,
                        'type' => 'in',
                        'quantity' => $productData['stock'],
                        'before_stock' => 0,
                        'after_stock' => $productData['stock'],
                        'reference_type' => 'initial',
                        'reference_id' => $product->id,
                        'notes' => 'Initial stock'
                    ]);

                    Log::info('Stock movement untuk batch berhasil dibuat', [
                        'stock_movement_id' => $stockMovement->id,
                        'quantity' => $stockMovement->quantity
                    ]);
                }

                $createdProducts[] = $product;
            }

            DB::commit();
            Log::info('Batch insert berhasil', [
                'products_count' => count($createdProducts)
            ]);

            return redirect()
                ->route('products.index')
                ->with('success', count($createdProducts) . ' produk berhasil ditambahkan');
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error saat melakukan batch insert: ' . $e->getMessage(), [
                'line' => $e->getLine(),
                'file' => $e->getFile(),
                'trace' => $e->getTraceAsString()
            ]);

            return back()->withInput()->with('error', 'Gagal menambahkan produk batch: ' . $e->getMessage());
        }
    }

    public function show(Product $product)
    {
        $product = Product::with(['category', 'stockMovements' => function ($query) {
            $query->latest();
        }])->findOrFail($product->id);
        return view('products.show', compact('product'));
    }

    public function edit(Product $product)
    {
        $categories = Category::orderBy('name')->get();
        $suppliers = Supplier::orderBy('name')->get();
        $units = UnitOfMeasure::orderBy('name')->get();

        // Get the product's supplier
        $productSupplier = $product->suppliers()->first();
        $supplierId = $productSupplier ? $productSupplier->id : null;

        // Load product units with their related unit information
        $product->load(['units.unit']);

        return view('products.edit', compact('product', 'categories', 'suppliers', 'units', 'supplierId'));
    }
    public function update(Request $request, Product $product)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'category_id' => 'required|exists:categories,id',
            'supplier_id' => 'required|exists:suppliers,id',
            'description' => 'nullable|string',
            'purchase_price' => 'required|numeric|min:0',
            'selling_price' => 'required|numeric|min:0',
            'min_stock' => 'required|numeric|min:0',
            'image' => 'nullable|image|max:2048',
            'units' => 'required|array|min:1',
            'units.*.unit_id' => 'required|exists:unit_of_measures,id',
            'units.*.conversion_factor' => 'required|numeric|min:0',
            'units.*.purchase_price' => 'required|numeric|min:0',
            'units.*.selling_price' => 'required|numeric|min:0',
            'units.*.barcode' => 'nullable|string|max:255',
        ]);

        DB::beginTransaction();

        try {
            // Update product basic info
            $product->update([
                'name' => $request->name,
                'category_id' => $request->category_id,
                'description' => $request->description,
                'purchase_price' => $request->purchase_price,
                'selling_price' => $request->selling_price,
                'min_stock' => $request->min_stock,
            ]);

            // Handle image upload if provided
            if ($request->hasFile('image')) {
                if ($product->image_path && Storage::exists('public/' . $product->image_path)) {
                    Storage::delete('public/' . $product->image_path);
                }
                $imagePath = $request->file('image')->store('products', 'public');
                $product->update(['image_path' => $imagePath]);
            }

            // Update supplier relationship
            $product->suppliers()->sync([$request->supplier_id => ['purchase_price' => $request->purchase_price]]);

            // Determine default unit
            $defaultUnitIndex = null;
            foreach ($request->units as $index => $unitData) {
                if (isset($unitData['is_default']) && $unitData['is_default']) {
                    $defaultUnitIndex = $index;
                    break;
                }
            }

            // If no default unit set, use first one
            if ($defaultUnitIndex === null) {
                $defaultUnitIndex = 0;
            }

            // Track existing and updated unit IDs
            $existingUnitIds = $product->units()->pluck('id')->toArray();
            $updatedUnitIds = [];

            // Update or create units
            foreach ($request->units as $index => $unitData) {
                $isDefault = ($index == $defaultUnitIndex);

                // Force conversion factor to 1 for default unit
                $conversionFactor = $isDefault ? 1 : $unitData['conversion_factor'];

                if (isset($unitData['id'])) {
                    $productUnit = ProductUnit::find($unitData['id']);
                    if ($productUnit && $productUnit->product_id == $product->id) {
                        $productUnit->update([
                            'unit_id' => $unitData['unit_id'],
                            'conversion_factor' => $conversionFactor,
                            'purchase_price' => $unitData['purchase_price'],
                            'selling_price' => $unitData['selling_price'],
                            'barcode' => $unitData['barcode'] ?? null,
                            'is_default' => $isDefault,
                        ]);
                        $updatedUnitIds[] = $productUnit->id;
                    }
                } else {
                    $productUnit = $product->units()->create([
                        'unit_id' => $unitData['unit_id'],
                        'conversion_factor' => $conversionFactor,
                        'purchase_price' => $unitData['purchase_price'],
                        'selling_price' => $unitData['selling_price'],
                        'barcode' => $unitData['barcode'] ?? null,
                        'is_default' => $isDefault,
                    ]);
                    $updatedUnitIds[] = $productUnit->id;
                }
            }

            // Delete units that weren't updated
            $unitsToDelete = array_diff($existingUnitIds, $updatedUnitIds);
            if (!empty($unitsToDelete)) {
                ProductUnit::whereIn('id', $unitsToDelete)->delete();
            }

            DB::commit();

            return redirect()->route('products.index')
                ->with('success', 'Produk berhasil diperbarui.');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()
                ->withInput()
                ->withErrors(['error' => 'Terjadi kesalahan: ' . $e->getMessage()]);
        }
    }

    public function duplicate(Product $product)
    {
        $categories = Category::all();
        $units = UnitOfMeasure::all();
        $suppliers = Supplier::all();

        // Generate kode produk baru
        $today = date('Ymd');
        $baseCode = 'PRD-' . $today . '-';
        $lastProduct = Product::withTrashed()
            ->where('code', 'like', $baseCode . '%')
            ->orderBy('code', 'desc')
            ->first();

        $lastNumber = 0;
        if ($lastProduct) {
            $lastNumber = (int) substr($lastProduct->code, -4);
        }

        $newNumber = $lastNumber + 1;
        $newCode = $baseCode . str_pad($newNumber, 4, '0', STR_PAD_LEFT);

        // Duplikasi data produk
        $duplicatedProduct = $product->replicate();
        $duplicatedProduct->name = 'Copy of ' . $product->name;
        $duplicatedProduct->code = $newCode;
        $duplicatedProduct->stock = 0; // Reset stock
        $duplicatedProduct->image_path = null; // Reset image

        return view('products.create', [
            'productTemplate' => $duplicatedProduct,
            'categories' => $categories,
            'units' => $units,
            'suppliers' => $suppliers,
            'productCode' => $newCode,
            'productUnits' => $product->productUnits
        ]);
    }

    public function destroy(Product $product)
    {
        // Delete image if exists
        if ($product->image_path) {
            Storage::disk('public')->delete($product->image_path);
        }

        $product->delete();

        return redirect()
            ->route('products.index')
            ->with('success', 'Product deleted successfully');
    }

    public function updateStock(Request $request, Product $product)
    {
        $validated = $request->validate([
            'adjustment_type' => 'required|in:add,subtract',
            'quantity' => 'required|integer|min:1',
            'notes' => 'nullable|string'
        ]);

        $beforeStock = $product->stock;
        $quantity = $validated['quantity'];

        if ($validated['adjustment_type'] === 'add') {
            $product->increment('stock', $quantity);
            $type = 'in';
        } else {
            if ($product->stock < $quantity) {
                return back()->with('error', 'Insufficient stock');
            }
            $product->decrement('stock', $quantity);
            $type = 'out';
        }

        // Record stock movement
        StockMovement::create([
            'product_id' => $product->id,
            'type' => $type,
            'quantity' => $quantity,
            'before_stock' => $beforeStock,
            'after_stock' => $product->stock,
            'reference_type' => 'adjustment',
            'reference_id' => $product->id,
            'notes' => $validated['notes'] ?? null
        ]);

        return back()->with('success', 'Stock updated successfully');
    }

    public function deleteImage(Product $product)
    {
        try {
            if ($product->image_path) {
                Storage::disk('public')->delete($product->image_path);
                $product->update(['image_path' => null]);
                return back()->with('success', 'Product image removed successfully');
            }

            return back()->with('error', 'No image to delete');
        } catch (\Exception $e) {
            // Log the error
            Log::error('Error deleting product image: ' . $e->getMessage());
            return back()->with('error', 'Failed to delete image. Please try again.');
        }
    }

    public function search(Request $request)
    {
        $search = $request->get('query');

        $products = Product::query()
            ->with('category')
            ->where(function ($query) use ($search) {
                $query->where('name', 'like', "%{$search}%")
                    ->orWhere('code', 'like', "%{$search}%")
                    ->orWhereHas('category', function ($q) use ($search) {
                        $q->where('name', 'like', "%{$search}%");
                    });
            })
            ->latest()
            ->take(10)
            ->get();

        return response()->json([
            'status' => 'success',
            'data' => $products
        ]);
    }
    public function getUnits(Product $product)
    {
        return response()->json([
            'stock' => $product->stock,
            'units' => $product->productUnits->map(function ($unit) {
                return [
                    'id' => $unit->id,
                    'unit_name' => $unit->unit->name,
                    'unit_abbreviation' => $unit->unit->abbreviation,
                    'selling_price' => $unit->selling_price,
                    'conversion_factor' => $unit->conversion_factor,
                    'is_default' => $unit->is_default
                ];
            })
        ]);
    }
}
