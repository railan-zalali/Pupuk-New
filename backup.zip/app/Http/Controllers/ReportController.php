<?php

namespace App\Http\Controllers;

// use App\Exports\ReportExport;
use App\Models\CashBook;
use App\Models\Customer;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\Sale;
use App\Models\SaleDetail;
use App\Models\Supplier;
use App\Models\User;
use App\Traits\ReportExport;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;

class ReportController extends Controller
{
    use ReportExport;

    /**
     * Display the report index/dashboard
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        // Get summary of recent data for dashboard
        $recentSales = Sale::whereDate('created_at', '>=', now()->subDays(30))
            ->count();

        $recentRevenue = Sale::whereDate('created_at', '>=', now()->subDays(30))
            ->sum('total_amount');

        $lowStockProducts = Product::where('stock', '<=', DB::raw('min_stock'))
            ->count();

        $pendingPayables = Purchase::where('payment_status', '!=', 'paid')
            ->sum('remaining_amount');

        $pendingReceivables = Sale::where('payment_status', '!=', 'paid')
            ->sum('remaining_amount');

        return view('reports.index', compact(
            'recentSales',
            'recentRevenue',
            'lowStockProducts',
            'pendingPayables',
            'pendingReceivables'
        ));
    }

    /**
     * Generate purchases report
     *
     * @param Request $request
     * @return \Illuminate\View\View|\Illuminate\Http\Response
     */
    public function purchases(Request $request)
    {
        try {
            // Parse date parameters with validation
            $startDate = $request->start_date ? Carbon::parse($request->start_date) : Carbon::now()->startOfMonth();
            $endDate = $request->end_date ? Carbon::parse($request->end_date)->endOfDay() : Carbon::now()->endOfDay();

            if ($startDate > $endDate) {
                return back()->with('error', 'Tanggal mulai tidak boleh lebih besar dari tanggal akhir');
            }

            // Cache key based on all filter parameters
            $cacheKey = 'purchases_report_' . $startDate->format('Ymd') . '_' . $endDate->format('Ymd') .
                '_' . ($request->supplier_id ?: 'all') . '_' . ($request->status ?: 'all');

            // Get or generate report data with cache
            $data = Cache::remember($cacheKey, now()->addHours(3), function () use ($request, $startDate, $endDate) {
                $suppliers = Supplier::orderBy('name')->get();

                $purchasesQuery = Purchase::with(['supplier', 'purchaseDetails.product'])
                    ->whereBetween('created_at', [$startDate, $endDate]);

                // Apply filters
                if ($request->supplier_id) {
                    $purchasesQuery->where('supplier_id', $request->supplier_id);
                }

                if ($request->status) {
                    $purchasesQuery->where('status', $request->status);
                }

                $purchases = $purchasesQuery->latest()->paginate(20);

                // Calculate status counts efficiently
                $statusCounts = Purchase::whereBetween('created_at', [$startDate, $endDate])
                    ->selectRaw('status, count(*) as count')
                    ->groupBy('status')
                    ->pluck('count', 'status')
                    ->toArray();

                // Calculate summary statistics
                $totalAmount = $purchases->sum('total_amount');
                $totalCount = $purchases->total();
                $averagePurchase = $totalCount > 0 ? $totalAmount / $totalCount : 0;

                return [
                    'purchases' => $purchases,
                    'suppliers' => $suppliers,
                    'startDate' => $startDate,
                    'endDate' => $endDate,
                    'summary' => [
                        'total_purchases' => $totalCount,
                        'total_amount' => $totalAmount,
                        'average_purchase' => $averagePurchase,
                        'status_counts' => $statusCounts
                    ],
                    'headers' => [
                        'Date' => 'date',
                        'Invoice' => 'invoice_number',
                        'Supplier' => 'supplier_name',
                        'Amount' => 'total_amount',
                        'Status' => 'status'
                    ],
                    'items' => $purchases->items()
                ];
            });

            return $this->handleExport(
                $data,
                'purchases',
                'purchase_report_' . $startDate->format('Y-m-d') . '_' . $endDate->format('Y-m-d')
            );
        } catch (\Exception $e) {
            Log::error('Purchase Report Error: ' . $e->getMessage(), [
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString()
            ]);

            return back()->with('error', 'Terjadi kesalahan saat memuat laporan: ' . $e->getMessage());
        }
    }

    /**
     * Generate sales report
     *
     * @param Request $request
     * @return \Illuminate\View\View|\Illuminate\Http\Response
     */
    public function sales(Request $request)
    {
        try {
            // Parse date parameters with validation
            $startDate = $request->start_date ? Carbon::parse($request->start_date) : Carbon::now()->startOfMonth();
            $endDate = $request->end_date ? Carbon::parse($request->end_date)->endOfDay() : Carbon::now()->endOfDay();

            if ($startDate > $endDate) {
                return back()->with('error', 'Tanggal mulai tidak boleh lebih besar dari tanggal akhir');
            }

            // Cache key based on all filter parameters
            $cacheKey = 'sales_report_' . $startDate->format('Ymd') . '_' . $endDate->format('Ymd') .
                '_' . ($request->payment_method ?: 'all') . '_' . ($request->customer_id ?: 'all');

            // Get or generate report data with cache
            $data = Cache::remember($cacheKey, now()->addHours(2), function () use ($request, $startDate, $endDate) {
                $salesQuery = Sale::with(['user:id,name', 'customer:id,name', 'saleDetails.product:id,name,code,selling_price'])
                    ->whereBetween('created_at', [$startDate, $endDate]);

                // Apply filters
                if ($request->payment_method) {
                    $salesQuery->where('payment_method', $request->payment_method);
                }

                if ($request->customer_id) {
                    $salesQuery->where('customer_id', $request->customer_id);
                }

                $sales = $salesQuery->latest()->paginate(20);

                // Prepare chart data for sales by date
                $salesByDate = $this->getSalesByDateChart($startDate, $endDate);

                // Calculate payment method distribution
                $paymentMethods = Sale::whereBetween('created_at', [$startDate, $endDate])
                    ->selectRaw('payment_method, count(*) as count, sum(total_amount) as total')
                    ->groupBy('payment_method')
                    ->pluck('count', 'payment_method')
                    ->toArray();

                // Calculate total products sold
                $totalProductsSold = SaleDetail::whereHas('sale', function ($query) use ($startDate, $endDate) {
                    $query->whereBetween('created_at', [$startDate, $endDate]);
                })->sum('quantity');

                $avgProductsPerTransaction = $sales->total() > 0
                    ? $totalProductsSold / $sales->total()
                    : 0;

                // Best selling products
                $bestSellingProducts = SaleDetail::whereHas('sale', function ($query) use ($startDate, $endDate) {
                    $query->whereBetween('created_at', [$startDate, $endDate]);
                })
                    ->select('product_id', DB::raw('SUM(quantity) as total_quantity'))
                    ->with('product:id,name,code,selling_price')
                    ->groupBy('product_id')
                    ->orderByDesc('total_quantity')
                    ->limit(5)
                    ->get();

                return [
                    'sales' => $sales,
                    'startDate' => $startDate,
                    'endDate' => $endDate,
                    'salesChartData' => $salesByDate,
                    'bestSellingProducts' => $bestSellingProducts,
                    'summary' => [
                        'total_sales' => $sales->total(),
                        'total_amount' => $sales->sum('total_amount'),
                        'average_sale' => $sales->total() > 0 ? $sales->sum('total_amount') / $sales->total() : 0,
                        'payment_methods' => $paymentMethods,
                        'total_products_sold' => $totalProductsSold,
                        'avg_products_per_transaction' => round($avgProductsPerTransaction, 1)
                    ],
                    'headers' => [
                        'Date' => 'date',
                        'Invoice' => 'invoice_number',
                        'Customer' => 'customer_name',
                        'Amount' => 'total_amount',
                        'Payment' => 'payment_method'
                    ],
                    'items' => $sales->items()
                ];
            });

            return $this->handleExport(
                $data,
                'sales',
                'sales_report_' . $startDate->format('Y-m-d') . '_' . $endDate->format('Y-m-d')
            );
        } catch (\Exception $e) {
            Log::error('Sales Report Error: ' . $e->getMessage(), [
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString(),
                'request_data' => $request->all()
            ]);

            return back()->with('error', 'Terjadi kesalahan saat memuat laporan: ' . $e->getMessage());
        }
    }

        /**
     * Generate accounts receivable and payable report
     *
     * @param Request $request
     * @return \Illuminate\View\View|\Illuminate\Http\Response
     */
    public function accounts(Request $request)
    {
        try {
            // Validate date inputs
            $request->validate([
                'start_date' => 'nullable|date_format:Y-m-d',
                'end_date' => 'nullable|date_format:Y-m-d',
            ]);

            $startDate = $request->start_date ? Carbon::parse($request->start_date) : Carbon::now()->startOfMonth();
            $endDate = $request->end_date ? Carbon::parse($request->end_date)->endOfDay() : Carbon::now()->endOfDay();

            if ($startDate > $endDate) {
                return back()->with('error', 'Tanggal mulai tidak boleh lebih besar dari tanggal akhir');
            }

            // Cache key for better performance
            $cacheKey = 'accounts_report_' . $startDate->format('Ymd') . '_' . $endDate->format('Ymd');

            $data = Cache::remember($cacheKey, now()->addHours(3), function () use ($startDate, $endDate) {
                // Optimize queries with specific columns
                $payables = Purchase::select([
                    'id',
                    'invoice_number',
                    'date',
                    'total_amount',
                    'paid_amount',
                    'remaining_amount',
                    'payment_status',
                    'supplier_id',
                    'due_date'
                ])
                    ->with(['supplier:id,name,phone,email'])
                    ->where('payment_status', '!=', 'paid')
                    ->whereBetween('date', [$startDate, $endDate])
                    ->orderBy('due_date')
                    ->get();

                $receivables = Sale::select([
                    'id',
                    'invoice_number',
                    'date',
                    'total_amount',
                    'paid_amount',
                    'remaining_amount',
                    'payment_status',
                    'customer_id',
                    'due_date'
                ])
                    ->with(['customer:id,name,phone,email'])
                    ->where('payment_status', '!=', 'paid')
                    ->whereBetween('date', [$startDate, $endDate])
                    ->orderBy('due_date')
                    ->get();

                // Group by status for summary
                $payablesByStatus = $payables->groupBy('payment_status')
                    ->map(function ($group) {
                        return [
                            'count' => $group->count(),
                            'amount' => $group->sum('remaining_amount')
                        ];
                    });

                $receivablesByStatus = $receivables->groupBy('payment_status')
                    ->map(function ($group) {
                        return [
                            'count' => $group->count(),
                            'amount' => $group->sum('remaining_amount')
                        ];
                    });

                // Group by due date age for aging report
                $now = Carbon::now();
                $agingCategories = [
                    'not_due' => 'Belum Jatuh Tempo',
                    'days_1_30' => '1-30 Hari',
                    'days_31_60' => '31-60 Hari',
                    'days_61_90' => '61-90 Hari',
                    'days_90_plus' => 'Lebih dari 90 Hari'
                ];

                $receivablesAging = [
                    'not_due' => 0,
                    'days_1_30' => 0,
                    'days_31_60' => 0,
                    'days_61_90' => 0,
                    'days_90_plus' => 0
                ];

                $payablesAging = [
                    'not_due' => 0,
                    'days_1_30' => 0,
                    'days_31_60' => 0,
                    'days_61_90' => 0,
                    'days_90_plus' => 0
                ];

                // Calculate aging for receivables
                foreach ($receivables as $receivable) {
                    if (!$receivable->due_date) continue;

                    $dueDate = Carbon::parse($receivable->due_date);
                    $daysPastDue = $now->diffInDays($dueDate, false);

                    if ($daysPastDue >= 0) {
                        $receivablesAging['not_due'] += $receivable->remaining_amount;
                    } elseif ($daysPastDue >= -30) {
                        $receivablesAging['days_1_30'] += $receivable->remaining_amount;
                    } elseif ($daysPastDue >= -60) {
                        $receivablesAging['days_31_60'] += $receivable->remaining_amount;
                    } elseif ($daysPastDue >= -90) {
                        $receivablesAging['days_61_90'] += $receivable->remaining_amount;
                    } else {
                        $receivablesAging['days_90_plus'] += $receivable->remaining_amount;
                    }
                }

                // Calculate aging for payables
                foreach ($payables as $payable) {
                    if (!$payable->due_date) continue;

                    $dueDate = Carbon::parse($payable->due_date);
                    $daysPastDue = $now->diffInDays($dueDate, false);

                    if ($daysPastDue >= 0) {
                        $payablesAging['not_due'] += $payable->remaining_amount;
                    } elseif ($daysPastDue >= -30) {
                        $payablesAging['days_1_30'] += $payable->remaining_amount;
                    } elseif ($daysPastDue >= -60) {
                        $payablesAging['days_31_60'] += $payable->remaining_amount;
                    } elseif ($daysPastDue >= -90) {
                        $payablesAging['days_61_90'] += $payable->remaining_amount;
                    } else {
                        $payablesAging['days_90_plus'] += $payable->remaining_amount;
                    }
                }

                return [
                    'startDate' => $startDate,
                    'endDate' => $endDate,
                    'payables' => $payables,
                    'receivables' => $receivables,
                    'payablesByStatus' => $payablesByStatus,
                    'receivablesByStatus' => $receivablesByStatus,
                    'agingCategories' => $agingCategories,
                    'receivablesAging' => $receivablesAging,
                    'payablesAging' => $payablesAging,
                    'summary' => [
                        'total_payables' => $payables->sum('remaining_amount'),
                        'total_receivables' => $receivables->sum('remaining_amount'),
                        'net_balance' => $receivables->sum('remaining_amount') - $payables->sum('remaining_amount')
                    ]
                ];
            });

            return $this->handleExport(
                $data,
                'accounts',
                'accounts_report_' . $startDate->format('Y-m-d') . '_' . $endDate->format('Y-m-d')
            );
        } catch (\Exception $e) {
            Log::error('Accounts Report Error: ' . $e->getMessage(), [
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString()
            ]);

            return back()->with('error', 'Terjadi kesalahan saat memuat laporan: ' . $e->getMessage());
        }
    }

    /**
     * Generate cash flow report
     *
     * @param Request $request
     * @return \Illuminate\View\View|\Illuminate\Http\Response
     */
    public function cashFlow(Request $request)
    {
        try {
            // Validate date inputs
            $request->validate([
                'start_date' => 'nullable|date_format:Y-m-d',
                'end_date' => 'nullable|date_format:Y-m-d',
            ]);

            $startDate = $request->start_date ? Carbon::parse($request->start_date) : Carbon::now()->startOfMonth();
            $endDate = $request->end_date ? Carbon::parse($request->end_date)->endOfDay() : Carbon::now()->endOfDay();

            if ($startDate > $endDate) {
                return back()->with('error', 'Tanggal mulai tidak boleh lebih besar dari tanggal akhir');
            }

            // Cache key for better performance
            $cacheKey = 'cash_flow_' . $startDate->format('Ymd') . '_' . $endDate->format('Ymd');

            $data = Cache::remember($cacheKey, now()->addHours(3), function () use ($startDate, $endDate) {
                $cashBooks = CashBook::whereBetween('date', [$startDate, $endDate])
                    ->orderBy('date')
                    ->get();

                // Calculate cash flow data for chart
                $period = CarbonPeriod::create($startDate, '1 day', $endDate);
                $cashFlowChartData = [
                    'labels' => [],
                    'income' => [],
                    'expense' => [],
                    'balance' => []
                ];

                foreach ($period as $date) {
                    $dateStr = $date->format('Y-m-d');
                    $dailyIncome = $cashBooks->where('date', $dateStr)
                        ->where('type', 'income')
                        ->sum('amount');

                    $dailyExpense = $cashBooks->where('date', $dateStr)
                        ->where('type', 'expense')
                        ->sum('amount');

                    $cashFlowChartData['labels'][] = $date->format('d/m/Y');
                    $cashFlowChartData['income'][] = $dailyIncome;
                    $cashFlowChartData['expense'][] = $dailyExpense;
                    $cashFlowChartData['balance'][] = $dailyIncome - $dailyExpense;
                }

                // Calculate income by categories
                $incomeCategories = CashBook::whereBetween('date', [$startDate, $endDate])
                    ->where('type', 'income')
                    ->selectRaw('category, sum(amount) as total')
                    ->groupBy('category')
                    ->orderByDesc('total')
                    ->get()
                    ->pluck('total', 'category')
                    ->toArray();

                // Calculate expense by categories
                $expenseCategories = CashBook::whereBetween('date', [$startDate, $endDate])
                    ->where('type', 'expense')
                    ->selectRaw('category, sum(amount) as total')
                    ->groupBy('category')
                    ->orderByDesc('total')
                    ->get()
                    ->pluck('total', 'category')
                    ->toArray();

                return [
                    'cashBooks' => $cashBooks,
                    'startDate' => $startDate,
                    'endDate' => $endDate,
                    'cashFlowChartData' => $cashFlowChartData,
                    'incomeCategories' => $incomeCategories,
                    'expenseCategories' => $expenseCategories,
                    'summary' => [
                        'total_income' => $cashBooks->where('type', 'income')->sum('amount'),
                        'total_expense' => $cashBooks->where('type', 'expense')->sum('amount'),
                        'net_flow' => $cashBooks->where('type', 'income')->sum('amount') - $cashBooks->where('type', 'expense')->sum('amount'),
                        'total_transactions' => $cashBooks->count()
                    ],
                    'headers' => [
                        'Date' => 'date',
                        'Category' => 'category',
                        'Description' => 'description',
                        'Type' => 'type',
                        'Amount' => 'amount'
                    ],
                    'items' => $cashBooks
                ];
            });

            return $this->handleExport(
                $data,
                'cash-flow',
                'cash_flow_report_' . $startDate->format('Y-m-d') . '_' . $endDate->format('Y-m-d')
            );
        } catch (\Exception $e) {
            Log::error('Cash Flow Report Error: ' . $e->getMessage(), [
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString()
            ]);

            // More generic error message for users
            return back()->with('error', 'Terjadi kesalahan saat memuat laporan. Silakan coba lagi nanti.');
        }
    }

    /**
     * Generate inventory stock report
     *
     * @param Request $request
     * @return \Illuminate\View\View|\Illuminate\Http\Response
     */
    public function stock(Request $request)
    {
        try {
            // Cache key for stock report
            $cacheKey = 'stock_report_' . ($request->category_id ?: 'all') . '_' . ($request->status ?: 'all');

            $data = Cache::remember($cacheKey, now()->addHours(6), function () use ($request) {
                $productsQuery = Product::with('category')
                    ->withSum('purchaseDetails as total_purchased', 'quantity')
                    ->withSum('saleDetails as total_sold', 'quantity');

                // Apply filters
                if ($request->category_id) {
                    $productsQuery->where('category_id', $request->category_id);
                }

                if ($request->status === 'low_stock') {
                    $productsQuery->whereRaw('stock <= min_stock');
                } elseif ($request->status === 'out_of_stock') {
                    $productsQuery->where('stock', 0);
                } elseif ($request->status === 'in_stock') {
                    $productsQuery->where('stock', '>', 0);
                }

                $products = $productsQuery->paginate(15);

                $productsCollection = $products->getCollection()->map(function ($product) {
                    $product->stock_value = $product->stock * $product->purchase_price;
                    return $product;
                });

                // Replace the collection in the paginator with our modified collection
                $products->setCollection($productsCollection);

                // Calculate stock value by category for chart
                $stockByCategory = Product::join('categories', 'products.category_id', '=', 'categories.id')
                    ->select('categories.name', DB::raw('SUM(products.stock * products.purchase_price) as stock_value'))
                    ->groupBy('categories.id', 'categories.name')
                    ->orderByDesc('stock_value')
                    ->get()
                    ->pluck('stock_value', 'name')
                    ->toArray();

                return [
                    'products' => $products,
                    'stockByCategory' => $stockByCategory,
                    'summary' => [
                        'total_products' => Product::count(),
                        'total_stock_value' => Product::sum(DB::raw('stock * purchase_price')),
                        'low_stock_count' => Product::whereRaw('stock <= min_stock')->count(),
                        'out_of_stock_count' => Product::where('stock', 0)->count()
                    ],
                    'headers' => [
                        'Code' => 'code',
                        'Name' => 'name',
                        'Category' => 'category_name',
                        'Stock' => 'stock',
                        'Min Stock' => 'min_stock',
                        'Value' => 'stock_value'
                    ],
                    'items' => $products,
                    'date' => now()
                ];
            });

            return $this->handleExport(
                $data,
                'stock',
                'stock_report_' . now()->format('Y-m-d')
            );
        } catch (\Exception $e) {
            Log::error('Stock Report Error: ' . $e->getMessage(), [
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString()
            ]);

            return back()->with('error', 'Terjadi kesalahan saat memuat laporan: ' . $e->getMessage());
        }
    }

    /**
     * Generate profit and loss report
     *
     * @param Request $request
     * @return \Illuminate\View\View|\Illuminate\Http\Response
     */
    public function profitLoss(Request $request)
    {
        try {
            // Validasi input date
            $startDate = $request->get('start_date')
                ? Carbon::parse($request->get('start_date'))->startOfDay()
                : Carbon::now()->startOfMonth();

            $endDate = $request->get('end_date')
                ? Carbon::parse($request->get('end_date'))->endOfDay()
                : Carbon::now()->endOfDay();

            // Validasi range tanggal
            if ($startDate > $endDate) {
                return back()->with('error', 'Tanggal mulai tidak boleh lebih besar dari tanggal akhir');
            }

            // Cache key berdasarkan parameter filter
            $cacheKey = 'profit_loss_' . $startDate->format('Ymd') . '_' . $endDate->format('Ymd');

            // Ambil data dari cache atau generate jika belum ada
            $data = Cache::remember($cacheKey, now()->addHours(12), function () use ($startDate, $endDate) {
                // Hitung penjualan dengan query builder yang dioptimasi
                $salesData = Sale::whereBetween('created_at', [$startDate, $endDate])
                    ->whereNull('deleted_at')
                    ->select([
                        'id',
                        'invoice_number',
                        'total_amount',
                        'created_at',
                    ])
                    ->get();

                // Hitung pembelian dengan query builder yang dioptimasi
                $purchasesData = Purchase::whereBetween('created_at', [$startDate, $endDate])
                    ->whereNull('deleted_at')
                    ->select([
                        'id',
                        'invoice_number',
                        'total_amount',
                        'created_at',
                    ])
                    ->get();

                // Hitung pengeluaran operasional
                $expenses = CashBook::where('type', 'expense')
                    ->whereBetween('date', [$startDate->format('Y-m-d'), $endDate->format('Y-m-d')])
                    ->sum('amount');

                // Hitung pendapatan lainnya
                $otherIncome = CashBook::where('type', 'income')
                    ->whereNotIn('category', ['sales']) // Exclude sales income
                    ->whereBetween('date', [$startDate->format('Y-m-d'), $endDate->format('Y-m-d')])
                    ->sum('amount');

                // Hitung total
                $totalSales = $salesData->sum('total_amount');
                $totalPurchases = $purchasesData->sum('total_amount');
                $grossProfit = $totalSales - $totalPurchases;
                $netProfit = $grossProfit + $otherIncome - $expenses;

                // Prepare data untuk profit trend chart
                $profitTrend = $this->calculateProfitTrend($startDate, $endDate);

                // Prepare items untuk tabel transaksi
                $items = collect()
                    ->concat($salesData->map(function ($sale) {
                        return [
                            'date' => $sale->created_at->format('Y-m-d'),
                            'type' => 'Sale',
                            'reference' => $sale->invoice_number,
                            'amount' => $sale->total_amount
                        ];
                    }))
                    ->concat($purchasesData->map(function ($purchase) {
                        return [
                            'date' => $purchase->created_at->format('Y-m-d'),
                            'type' => 'Purchase',
                            'reference' => $purchase->invoice_number,
                            'amount' => -$purchase->total_amount
                        ];
                    }))
                    ->sortByDesc('date');

                return [
                    'startDate' => $startDate,
                    'endDate' => $endDate,
                    'profitTrend' => $profitTrend,
                    'summary' => [
                        'total_sales' => $totalSales,
                        'total_purchases' => $totalPurchases,
                        'expenses' => $expenses,
                        'other_income' => $otherIncome,
                        'gross_profit' => $grossProfit,
                        'net_profit' => $netProfit,
                        'total_transactions' => $salesData->count() + $purchasesData->count(),
                        'profit_margin_percentage' => $totalSales > 0 ? ($grossProfit / $totalSales) * 100 : 0
                    ],
                    'headers' => [
                        'Date' => 'date',
                        'Type' => 'type',
                        'Reference' => 'reference',
                        'Amount' => 'amount'
                    ],
                    'items' => $items,
                    'date' => now()
                ];
            });

            return $this->handleExport(
                $data,
                'profit-loss',
                'profit_loss_report_' . $startDate->format('Y-m-d') . '_' . $endDate->format('Y-m-d')
            );
        } catch (\Exception $e) {
            Log::error('Error in profit loss report: ' . $e->getMessage(), [
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString()
            ]);

            return back()->with('error', 'Terjadi kesalahan saat memuat laporan: ' . $e->getMessage());
        }
    }

    /**
     * Generate sales performance report
     *
     * @param Request $request
     * @return \Illuminate\View\View|\Illuminate\Http\Response
     */
    public function salesPerformance(Request $request)
    {
        try {
            $startDate = $request->start_date ? Carbon::parse($request->start_date) : Carbon::now()->startOfMonth();
            $endDate = $request->end_date ? Carbon::parse($request->end_date)->endOfDay() : Carbon::now()->endOfDay();

            if ($startDate > $endDate) {
                return back()->with('error', 'Tanggal mulai tidak boleh lebih besar dari tanggal akhir');
            }

            // Get user performance data
            $userPerformance = Sale::whereBetween('created_at', [$startDate, $endDate])
                ->select('user_id', DB::raw('COUNT(*) as transaction_count'), DB::raw('SUM(total_amount) as total_amount'))
                ->with('user:id,name')
                ->groupBy('user_id')
                ->orderByDesc('total_amount')
                ->get();

            // Get best selling products
            $bestSellingProducts = SaleDetail::whereHas('sale', function ($query) use ($startDate, $endDate) {
                $query->whereBetween('created_at', [$startDate, $endDate]);
            })
                ->select(
                    'product_id',
                    DB::raw('SUM(quantity) as total_quantity'),
                    DB::raw('SUM(quantity * price) as total_revenue')
                )
                ->with('product:id,name,code,purchase_price,selling_price')
                ->groupBy('product_id')
                ->orderByDesc('total_quantity')
                ->limit(10)
                ->get()
                ->map(function ($item) {
                    $item->profit_margin = $item->product->selling_price - $item->product->purchase_price;
                    $item->total_profit = $item->total_quantity * $item->profit_margin;
                    return $item;
                });

            // Get sales by hour of day
            $salesByHour = Sale::whereBetween('created_at', [$startDate, $endDate])
                ->select(DB::raw('HOUR(created_at) as hour'), DB::raw('COUNT(*) as count'), DB::raw('SUM(total_amount) as amount'))
                ->groupBy(DB::raw('HOUR(created_at)'))
                ->orderBy('hour')
                ->get()
                ->pluck('amount', 'hour')
                ->toArray();

            // Fill in missing hours
            for ($i = 0; $i < 24; $i++) {
                if (!isset($salesByHour[$i])) {
                    $salesByHour[$i] = 0;
                }
            }
            ksort($salesByHour);

            // Get sales by day of week
            $salesByDayOfWeek = Sale::whereBetween('created_at', [$startDate, $endDate])
                ->select(DB::raw('DAYOFWEEK(created_at) as day'), DB::raw('COUNT(*) as count'), DB::raw('SUM(total_amount) as amount'))
                ->groupBy(DB::raw('DAYOFWEEK(created_at)'))
                ->orderBy('day')
                ->get();

            $dayNames = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
            $salesByDay = [];

            foreach ($dayNames as $index => $name) {
                $dayNumber = $index + 1;
                $dayData = $salesByDayOfWeek->firstWhere('day', $dayNumber);
                $salesByDay[$name] = $dayData ? $dayData->amount : 0;
            }

            $data = [
                'startDate' => $startDate,
                'endDate' => $endDate,
                'userPerformance' => $userPerformance,
                'bestSellingProducts' => $bestSellingProducts,
                'salesByHour' => $salesByHour,
                'salesByDay' => $salesByDay,
                'summary' => [
                    'total_sales' => Sale::whereBetween('created_at', [$startDate, $endDate])->count(),
                    'total_revenue' => Sale::whereBetween('created_at', [$startDate, $endDate])->sum('total_amount'),
                    'total_products_sold' => SaleDetail::whereHas('sale', function ($query) use ($startDate, $endDate) {
                        $query->whereBetween('created_at', [$startDate, $endDate]);
                    })->sum('quantity'),
                    'average_transaction_value' => Sale::whereBetween('created_at', [$startDate, $endDate])->avg('total_amount') ?? 0
                ]
            ];

            return $this->handleExport(
                $data,
                'sales-performance',
                'sales_performance_' . $startDate->format('Y-m-d') . '_' . $endDate->format('Y-m-d')
            );
        } catch (\Exception $e) {
            Log::error('Sales Performance Report Error: ' . $e->getMessage(), [
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString()
            ]);

            return back()->with('error', 'Terjadi kesalahan saat memuat laporan: ' . $e->getMessage());
        }
    }

    /**
     * Generate product performance report
     *
     * @param Request $request
     * @return \Illuminate\View\View|\Illuminate\Http\Response
     */
    public function productPerformance(Request $request)
    {
        try {
            $startDate = $request->start_date ? Carbon::parse($request->start_date) : Carbon::now()->startOfMonth();
            $endDate = $request->end_date ? Carbon::parse($request->end_date)->endOfDay() : Carbon::now()->endOfDay();

            if ($startDate > $endDate) {
                return back()->with('error', 'Tanggal mulai tidak boleh lebih besar dari tanggal akhir');
            }

            // Get product performance data
            $productsPerformance = SaleDetail::join('products', 'sale_details.product_id', '=', 'products.id')
                ->join('sales', 'sale_details.sale_id', '=', 'sales.id')
                ->whereBetween('sales.created_at', [$startDate, $endDate])
                ->select(
                    'products.id',
                    'products.name',
                    'products.code',
                    'products.purchase_price',
                    'products.selling_price',
                    DB::raw('SUM(sale_details.quantity) as total_quantity'),
                    DB::raw('SUM(sale_details.quantity * sale_details.price) as total_revenue')
                )
                ->groupBy('products.id', 'products.name', 'products.code', 'products.purchase_price', 'products.selling_price')
                ->orderByDesc('total_quantity')
                ->paginate(20);

            // Calculate profit for each product
            $productsPerformance->getCollection()->transform(function ($item) {
                $item->profit_per_unit = $item->selling_price - $item->purchase_price;
                $item->total_profit = $item->total_quantity * $item->profit_per_unit;
                $item->profit_margin_percentage = $item->selling_price > 0
                    ? ($item->profit_per_unit / $item->selling_price) * 100
                    : 0;
                return $item;
            });

            // Get top categories
            $topCategories = SaleDetail::join('products', 'sale_details.product_id', '=', 'products.id')
                ->join('categories', 'products.category_id', '=', 'categories.id')
                ->join('sales', 'sale_details.sale_id', '=', 'sales.id')
                ->whereBetween('sales.created_at', [$startDate, $endDate])
                ->select(
                    'categories.id',
                    'categories.name',
                    DB::raw('SUM(sale_details.quantity) as total_quantity'),
                    DB::raw('SUM(sale_details.quantity * sale_details.price) as total_revenue')
                )
                ->groupBy('categories.id', 'categories.name')
                ->orderByDesc('total_revenue')
                ->get();

            $data = [
                'startDate' => $startDate,
                'endDate' => $endDate,
                'productsPerformance' => $productsPerformance,
                'topCategories' => $topCategories,
                'summary' => [
                    'total_products_sold' => SaleDetail::whereHas('sale', function ($query) use ($startDate, $endDate) {
                        $query->whereBetween('created_at', [$startDate, $endDate]);
                    })->sum('quantity'),
                    'total_revenue' => SaleDetail::whereHas('sale', function ($query) use ($startDate, $endDate) {
                        $query->whereBetween('created_at', [$startDate, $endDate]);
                    })->sum(DB::raw('quantity * price')),
                    'unique_products_sold' => SaleDetail::whereHas('sale', function ($query) use ($startDate, $endDate) {
                        $query->whereBetween('created_at', [$startDate, $endDate]);
                    })->distinct('product_id')->count('product_id')
                ]
            ];

            return $this->handleExport(
                $data,
                'product-performance',
                'product_performance_' . $startDate->format('Y-m-d') . '_' . $endDate->format('Y-m-d')
            );
        } catch (\Exception $e) {
            Log::error('Product Performance Report Error: ' . $e->getMessage(), [
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString()
            ]);

            return back()->with('error', 'Terjadi kesalahan saat memuat laporan: ' . $e->getMessage());
        }
    }

    /**
     * Generate customer analysis report
     *
     * @param Request $request
     * @return \Illuminate\View\View|\Illuminate\Http\Response
     */
    public function customerAnalysis(Request $request)
    {
        try {
            $startDate = $request->start_date ? Carbon::parse($request->start_date) : Carbon::now()->startOfMonth();
            $endDate = $request->end_date ? Carbon::parse($request->end_date)->endOfDay() : Carbon::now()->endOfDay();

            if ($startDate > $endDate) {
                return back()->with('error', 'Tanggal mulai tidak boleh lebih besar dari tanggal akhir');
            }

            // Get top customers
            $topCustomers = Sale::whereBetween('created_at', [$startDate, $endDate])
                ->whereNotNull('customer_id')
                ->select(
                    'customer_id',
                    DB::raw('COUNT(*) as transaction_count'),
                    DB::raw('SUM(total_amount) as total_spent'),
                    DB::raw('AVG(total_amount) as average_transaction')
                )
                ->with('customer:id,nama')
                ->groupBy('customer_id')
                ->orderByDesc('total_spent')
                ->limit(20)
                ->get();

            // Get new vs returning customers
            $allCustomerTransactions = Sale::whereBetween('created_at', [$startDate, $endDate])
                ->whereNotNull('customer_id')
                ->select('customer_id', 'created_at')
                ->orderBy('created_at')
                ->get()
                ->groupBy('customer_id');

            $newCustomers = 0;
            $returningCustomers = 0;

            foreach ($allCustomerTransactions as $customerId => $transactions) {
                // Check if customer had transactions before our period
                $hadPriorTransactions = Sale::where('customer_id', $customerId)
                    ->where('created_at', '<', $startDate)
                    ->exists();

                if ($hadPriorTransactions) {
                    $returningCustomers++;
                } else {
                    $newCustomers++;
                }
            }

            // Get customer purchase frequency
            $purchaseFrequency = [];
            foreach ($allCustomerTransactions as $customerId => $transactions) {
                $count = $transactions->count();
                if (!isset($purchaseFrequency[$count])) {
                    $purchaseFrequency[$count] = 0;
                }
                $purchaseFrequency[$count]++;
            }
            ksort($purchaseFrequency);

            // Get sales by customer type
            $salesByCustomerType = [
                'with_customer' => Sale::whereBetween('created_at', [$startDate, $endDate])
                    ->whereNotNull('customer_id')
                    ->sum('total_amount'),
                'without_customer' => Sale::whereBetween('created_at', [$startDate, $endDate])
                    ->whereNull('customer_id')
                    ->sum('total_amount')
            ];

            $data = [
                'startDate' => $startDate,
                'endDate' => $endDate,
                'topCustomers' => $topCustomers,
                'newVsReturning' => [
                    'new' => $newCustomers,
                    'returning' => $returningCustomers
                ],
                'purchaseFrequency' => $purchaseFrequency,
                'salesByCustomerType' => $salesByCustomerType,
                'summary' => [
                    'total_customers' => Sale::whereBetween('created_at', [$startDate, $endDate])
                        ->whereNotNull('customer_id')
                        ->distinct('customer_id')
                        ->count('customer_id'),
                    'total_transactions' => Sale::whereBetween('created_at', [$startDate, $endDate])->count(),
                    'total_revenue' => Sale::whereBetween('created_at', [$startDate, $endDate])->sum('total_amount'),
                    'average_transaction' => Sale::whereBetween('created_at', [$startDate, $endDate])->avg('total_amount') ?? 0
                ]
            ];

            return $this->handleExport(
                $data,
                'customer-analysis',
                'customer_analysis_' . $startDate->format('Y-m-d') . '_' . $endDate->format('Y-m-d')
            );
        } catch (\Exception $e) {
            Log::error('Customer Analysis Report Error: ' . $e->getMessage(), [
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString()
            ]);

            return back()->with('error', 'Terjadi kesalahan saat memuat laporan: ' . $e->getMessage());
        }
    }

    /**
     * Generate tax and finance report
     *
     * @param Request $request
     * @return \Illuminate\View\View|\Illuminate\Http\Response
     */
    public function taxFinance(Request $request)
    {
        try {
            // Default to current year if not specified
            $year = $request->year ? intval($request->year) : Carbon::now()->year;

            // Calculate monthly data
            $monthlyData = collect();

            for ($month = 1; $month <= 12; $month++) {
                $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
                $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();

                // Monthly sales
                $sales = Sale::whereBetween('created_at', [$startDate, $endDate])
                    ->sum('total_amount');

                // Monthly purchases
                $purchases = Purchase::whereBetween('created_at', [$startDate, $endDate])
                    ->sum('total_amount');

                // Operational expenses
                $expenses = CashBook::where('type', 'expense')
                    ->whereBetween('date', [$startDate->format('Y-m-d'), $endDate->format('Y-m-d')])
                    ->sum('amount');

                // Other income
                $otherIncome = CashBook::where('type', 'income')
                    ->whereNotIn('category', ['sales'])
                    ->whereBetween('date', [$startDate->format('Y-m-d'), $endDate->format('Y-m-d')])
                    ->sum('amount');

                // Calculate profit
                $grossProfit = $sales - $purchases;
                $netProfit = $grossProfit + $otherIncome - $expenses;

                // Calculate tax (assuming 10% of net profit for example)
                $taxAmount = max(0, $netProfit * 0.10);

                $monthlyData->push([
                    'month' => $startDate->format('F'),
                    'month_number' => $month,
                    'sales' => $sales,
                    'purchases' => $purchases,
                    'expenses' => $expenses,
                    'other_income' => $otherIncome,
                    'gross_profit' => $grossProfit,
                    'net_profit' => $netProfit,
                    'tax_amount' => $taxAmount
                ]);
            }

            // Calculate yearly totals
            $yearlyTotals = [
                'sales' => $monthlyData->sum('sales'),
                'purchases' => $monthlyData->sum('purchases'),
                'expenses' => $monthlyData->sum('expenses'),
                'other_income' => $monthlyData->sum('other_income'),
                'gross_profit' => $monthlyData->sum('gross_profit'),
                'net_profit' => $monthlyData->sum('net_profit'),
                'tax_amount' => $monthlyData->sum('tax_amount')
            ];

            $data = [
                'year' => $year,
                'monthlyData' => $monthlyData,
                'yearlyTotals' => $yearlyTotals,
                'summary' => [
                    'total_sales' => $yearlyTotals['sales'],
                    'total_expenses' => $yearlyTotals['purchases'] + $yearlyTotals['expenses'],
                    'net_profit' => $yearlyTotals['net_profit'],
                    'total_tax' => $yearlyTotals['tax_amount']
                ]
            ];

            return $this->handleExport(
                $data,
                'tax-finance',
                'tax_finance_report_' . $year
            );
        } catch (\Exception $e) {
            Log::error('Tax Finance Report Error: ' . $e->getMessage(), [
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString()
            ]);

            return back()->with('error', 'Terjadi kesalahan saat memuat laporan: ' . $e->getMessage());
        }
    }

    /**
     * Calculate profit trend data for chart
     *
     * @param Carbon $startDate
     * @param Carbon $endDate
     * @return array
     */
    private function calculateProfitTrend(Carbon $startDate, Carbon $endDate)
    {
        // Determine interval based on date range
        $diffInDays = $startDate->diffInDays($endDate);

        if ($diffInDays <= 31) {
            // Daily grouping for a month or less
            $interval = 'day';
            $format = 'Y-m-d';
            $displayFormat = 'd/m';
        } elseif ($diffInDays <= 92) {
            // Weekly grouping for 3 months or less
            $interval = 'week';
            $format = 'Y-W';
            $displayFormat = 'W/Y';
        } else {
            // Monthly grouping for more than 3 months
            $interval = 'month';
            $format = 'Y-m';
            $displayFormat = 'M Y';
        }

        // Get sales grouped by interval
        $sales = Sale::whereBetween('created_at', [$startDate, $endDate])
            ->selectRaw("DATE_FORMAT(created_at, '%{$format}') as period, SUM(total_amount) as total")
            ->groupBy('period')
            ->orderBy('period')
            ->pluck('total', 'period')
            ->toArray();

        // Get purchases grouped by interval
        $purchases = Purchase::whereBetween('created_at', [$startDate, $endDate])
            ->selectRaw("DATE_FORMAT(created_at, '%{$format}') as period, SUM(total_amount) as total")
            ->groupBy('period')
            ->orderBy('period')
            ->pluck('total', 'period')
            ->toArray();

        // Calculate profit for each period
        $profitTrend = [];
        $periods = array_unique(array_merge(array_keys($sales), array_keys($purchases)));
        sort($periods);

        foreach ($periods as $period) {
            $saleAmount = $sales[$period] ?? 0;
            $purchaseAmount = $purchases[$period] ?? 0;
            $profit = $saleAmount - $purchaseAmount;

            // Format display label based on interval
            if ($interval === 'day') {
                $date = Carbon::createFromFormat('Y-m-d', $period);
                $label = $date->format($displayFormat);
            } elseif ($interval === 'week') {
                list($year, $week) = explode('-', $period);
                $label = "W{$week}/{$year}";
            } else {
                $date = Carbon::createFromFormat('Y-m', $period);
                $label = $date->format($displayFormat);
            }

            $profitTrend[$label] = $profit;
        }

        return $profitTrend;
    }

    /**
     * Calculate sales by date for chart
     *
     * @param Carbon $startDate
     * @param Carbon $endDate
     * @return array
     */
    private function getSalesByDateChart(Carbon $startDate, Carbon $endDate)
    {
        // Determine interval based on date range
        $diffInDays = $startDate->diffInDays($endDate);

        if ($diffInDays <= 31) {
            // Daily grouping for a month or less
            $groupBy = 'Y-m-d';
            $displayFormat = 'd/m';
        } elseif ($diffInDays <= 92) {
            // Weekly grouping for 3 months or less
            $groupBy = 'Y-W';
            $displayFormat = 'W/Y';
        } else {
            // Monthly grouping for more than 3 months
            $groupBy = 'Y-m';
            $displayFormat = 'M Y';
        }

        $salesByDate = Sale::whereBetween('created_at', [$startDate, $endDate])
        ->selectRaw("DATE_FORMAT(created_at, '%Y-%m-%d') as date, SUM(total_amount) as total")
        ->groupByRaw("DATE_FORMAT(created_at, '%Y-%m-%d')")  // Use the exact same expression here
        ->orderBy('date', 'asc')
        ->get();



        $chartData = [];

        foreach ($salesByDate as $sale) {
            if ($groupBy === 'Y-m-d') {
                $date = Carbon::createFromFormat('Y-m-d', $sale->date);
                $label = $date->format($displayFormat);
            } elseif ($groupBy === 'Y-W') {
                list($year, $week) = explode('-', $sale->date);
                $label = "W{$week}/{$year}";
            } else {
                $date = Carbon::createFromFormat('Y-m', $sale->date);
                $label = $date->format($displayFormat);
            }

            $chartData[$label] = $sale->total;
        }

        return $chartData;
    }
}
