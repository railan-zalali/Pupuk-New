<?php

namespace App\Http\Controllers;

use App\Models\purchases_receipts;
use App\Http\Requests\Storepurchases_receiptsRequest;
use App\Http\Requests\Updatepurchases_receiptsRequest;

class PurchasesReceiptsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Storepurchases_receiptsRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(purchases_receipts $purchases_receipts)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(purchases_receipts $purchases_receipts)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Updatepurchases_receiptsRequest $request, purchases_receipts $purchases_receipts)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(purchases_receipts $purchases_receipts)
    {
        //
    }
}
