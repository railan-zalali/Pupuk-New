<?php

namespace App\Traits;

use App\Models\Product;
use App\Models\Sale;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Facades\Excel;

trait ReportExport
{
    /**
 * Handle export based on request format
 *
 * @param array $data
 * @param string $view
 * @param string $filename
 * @return \Illuminate\View\View|\Illuminate\Http\Response
 */
protected function handleExport($data, $view, $filename)
{
    // Validate export format
    $format = request()->format ?? 'html';
    $validFormats = ['html', 'pdf', 'excel', 'csv'];

    if (!in_array($format, $validFormats)) {
        return back()->with('error', 'Format ekspor tidak valid. Gunakan: ' . implode(', ', $validFormats));
    }

    try {
        if ($format === 'html' || !$format) {
            return view('reports.' . $view, $data);
        } elseif ($format === 'pdf') {
            $pdf = PDF::loadView('reports.exports.' . $view, $data);
            return $pdf->download($filename . '.pdf');
        } elseif ($format === 'excel') {
            return Excel::download(new ReportExport($view, $data), $filename . '.xlsx');
        } elseif ($format === 'csv') {
            return Excel::download(new ReportExport($view, $data), $filename . '.csv', \Maatwebsite\Excel\Excel::CSV);
        }
    } catch (\Exception $e) {
        Log::error('Export Error: ' . $e->getMessage(), [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ]);

        return back()->with('error', 'Terjadi kesalahan saat mengekspor laporan. Silakan coba lagi nanti.');
    }
}

    protected function exportToExcel($data, $filename)
    {
        return response()->streamDownload(function () use ($data) {
            $output = fopen('php://output', 'w');

            // Header
            fputcsv($output, array_keys($data['headers']));

            // Data
            foreach ($data['items'] as $item) {
                fputcsv($output, $this->formatForCsv($item));
            }

            fclose($output);
        }, "{$filename}.csv", [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="' . $filename . '.csv"'
        ]);
    }

    protected function exportToPdf($data, $view, $filename)
    {
        $pdf = Pdf::loadView("reports.exports.{$view}", $data);
        return $pdf->download("{$filename}.pdf");
    }

    protected function formatForCsv($item)
    {
        if ($item instanceof Sale) {
            return [
                $item->created_at->format('d/m/Y H:i'),
                $item->invoice_number,
                $item->customer ? $item->customer->name : '-',
                $item->total_amount,
                $item->payment_method
            ];
        }

        if ($item instanceof Product) {
            return [
                $item->code,
                $item->name,
                $item->category->name,
                $item->stock,
                $item->min_stock,
                $item->stock_value
            ];
        }

        // Default format jika tidak cocok dengan model yang ada
        return array_values((array) $item);
    }
}
