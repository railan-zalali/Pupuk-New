<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Faktur Bibit #{{ $sale->invoice_number }}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            line-height: 1.4;
            color: #333;
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
        }

        .company-name {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .company-details {
            font-size: 12px;
            color: #555;
        }

        .document-title {
            font-size: 16px;
            font-weight: bold;
            text-align: center;
            margin: 20px 0;
            text-decoration: underline;
        }

        .document-number {
            font-size: 14px;
            text-align: center;
            margin-bottom: 20px;
        }

        .section {
            margin-bottom: 20px;
        }

        .section-title {
            font-weight: bold;
            margin-bottom: 5px;
            border-bottom: 1px solid #ddd;
            padding-bottom: 3px;
        }

        .details-table {
            width: 100%;
            margin-bottom: 15px;
        }

        .details-table td {
            padding: 3px 0;
        }

        .label {
            font-weight: bold;
            width: 150px;
        }

        table.items {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table.items th {
            background-color: #f2f2f2;
            text-align: left;
            padding: 8px;
            border: 1px solid #000;
        }

        table.items td {
            padding: 8px;
            border: 1px solid #000;
        }

        .totals {
            width: 100%;
            margin-top: 20px;
        }

        .totals td {
            padding: 3px 0;
        }

        .total-label {
            text-align: right;
            font-weight: bold;
            width: 80%;
        }

        .total-value {
            text-align: right;
            width: 20%;
        }

        .signatures {
            margin-top: 40px;
            width: 100%;
        }

        .signature-box {
            float: left;
            width: 33%;
            text-align: center;
        }

        .signature-line {
            border-top: 1px solid #000;
            margin-top: 50px;
            display: inline-block;
            width: 80%;
        }

        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 11px;
            color: #777;
            border-top: 1px solid #ddd;
            padding-top: 10px;
        }

        .tax-notice {
            margin-top: 20px;
            border: 2px solid #000;
            padding: 10px;
            text-align: center;
            font-weight: bold;
            font-size: 14px;
        }
    </style>
</head>

<body>
    <div class="header">
        <div class="company-name">TOKO PUPUK</div>
        <div class="company-details">
            Jl. Contoh No. 123, Kota<br>
            Telp: 0123456789 | Email: info@tokopupuk.com
        </div>
    </div>

    <div class="document-title">FAKTUR BIBIT</div>
    <div class="document-number">No: FB-{{ $sale->invoice_number }}</div>

    <div class="section">
        <div class="section-title">Informasi Transaksi</div>
        <table class="details-table">
            <tr>
                <td class="label">Tanggal:</td>
                <td>{{ \Carbon\Carbon::parse($sale->date)->format('d/m/Y') }}</td>
            </tr>
            <tr>
                <td class="label">No. Referensi:</td>
                <td>{{ $sale->invoice_number }}</td>
            </tr>
            <tr>
                <td class="label">Metode Pembayaran:</td>
                <td>
                    @if ($sale->payment_method == 'cash')
                        Tunai
                    @elseif($sale->payment_method == 'credit')
                        Kredit
                    @elseif($sale->payment_method == 'transfer')
                        Transfer Bank
                    @endif
                </td>
            </tr>
        </table>
    </div>

    @if ($sale->customer)
        <div class="section">
            <div class="section-title">Informasi Pelanggan</div>
            <table class="details-table">
                <tr>
                    <td class="label">Nama:</td>
                    <td>{{ $sale->customer->nama }}</td>
                </tr>
                <tr>
                    <td class="label">NIK:</td>
                    <td>{{ $sale->customer->nik }}</td>
                </tr>
                <tr>
                    <td class="label">Alamat:</td>
                    <td>
                        {{ $sale->customer->alamat ?? '-' }},
                        {{ $sale->customer->desa_nama }},
                        {{ $sale->customer->kecamatan_nama }},
                        {{ $sale->customer->kabupaten_nama ?? '' }}
                        {{ $sale->customer->provinsi_nama ?? '' }}
                    </td>
                </tr>
            </table>
        </div>
    @endif

    <div class="section">
        <div class="section-title">Detail Bibit</div>
        <table class="items">
            <thead>
                <tr>
                    <th width="5%">No</th>
                    <th width="15%">Kode</th>
                    <th width="40%">Nama Bibit</th>
                    <th width="10%">Jumlah</th>
                    <th width="15%">Harga</th>
                    <th width="15%">Subtotal</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($saleDetails as $index => $detail)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>{{ $detail->product->code }}</td>
                        <td>{{ $detail->product->name }}</td>
                        <td>{{ $detail->quantity }}</td>
                        <td>Rp {{ number_format($detail->selling_price, 0, ',', '.') }}</td>
                        <td>Rp {{ number_format($detail->subtotal, 0, ',', '.') }}</td>
                    </tr>
                @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="5" class="total-label">Total:</td>
                    <td>Rp {{ number_format($saleDetails->sum('subtotal'), 0, ',', '.') }}</td>
                </tr>
            </tfoot>
        </table>
    </div>

    <div class="tax-notice">
        HARGA BELUM TERMASUK PPN<br>
        PPN DIBEBASKAN
    </div>

    @if ($sale->notes)
        <div class="section">
            <div class="section-title">Catatan</div>
            <p>{{ $sale->notes }}</p>
        </div>
    @endif

    <table class="signatures">
        <tr>
            <td width="33%" style="text-align: center;">
                Penerima
                <div class="signature-line"></div>
                <div style="margin-top: 5px;">(............................................)</div>
            </td>
            <td width="33%" style="text-align: center;">
                Pengirim
                <div class="signature-line"></div>
                <div style="margin-top: 5px;">(............................................)</div>
            </td>
            <td width="33%" style="text-align: center;">
                Hormat Kami
                <div class="signature-line"></div>
                <div style="margin-top: 5px;">(............................................)</div>
            </td>
        </tr>
    </table>

    <div class="footer">
        <p>Dokumen ini sah dan diproses secara elektronik. Tanda tangan tidak diperlukan.</p>
    </div>
</body>

</html>
